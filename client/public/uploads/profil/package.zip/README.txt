 __   __   ___    _   _    ___              ___     ___    _____    ___      _
 \ \ / /  / _ \  | | | |  | _ \     o O O  |   \   /   \  |_   _|  /   \    | |
  \ V /  | (_) | | |_| |  |   /    o       | |) |  | - |    | |    | - |    |_|
  _|_|_   \___/   \___/   |_|_\   TS__[O]  |___/   |_|_|   _|_|_   |_|_|   _(_)_
_| """ |_|"""""|_|"""""|_|"""""| <======|_|"""""|_|"""""|_|"""""|_|"""""|_| """ |
"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'
   ___     ___             _  _     ___     ___     ___      _       _       _
  |_ _|   / __|     o O O | || |   | __|   | _ \   | __|    | |     | |     | |
   | |    \__ \    o      | __ |   | _|    |   /   | _|     |_|     |_|     |_|
  |___|   |___/   TS__[O] |_||_|   |___|   |_|_\   |___|   _(_)_   _(_)_   _(_)_
_|"""""|_|"""""| <======|_|"""""|_|"""""|_|"""""|_|"""""|_| """ |_| """ |_| """ |
"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'

Welcome to your Discord Data Package!

Inside, you'll find a few JSON (JavaScript Object Notation) and CSV (Comma Separated Values) files
of the data we use to provide Discord's service to you. We've chosen these formats for ease of
processing. Furthermore, the files have been organized into logical groups to make it easy to
understand and work with (at least, we hope so)!

For more information, you can view our in-depth help article at the following URL:

https://support.discord.com/hc/articles/360004957991

All the best,
Discord Team
